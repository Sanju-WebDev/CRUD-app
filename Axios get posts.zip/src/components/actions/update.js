import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'https://jsonplaceholder.typicode.com'
});

export const fetchPosts = () => {
  return (dispatch) => {
      axiosInstance.get('/posts')
        .then(res => {
          const posts = res.data;
          dispatch(updatePosts(posts))
        })
        .catch(err => {
          console.error(err);
        })
  };
};

export const updatePosts = (posts) => {
  return {
    type: 'LIST_POSTS', 
    payload: posts
  }
}