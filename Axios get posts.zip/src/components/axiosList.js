import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchPosts } from './actions/update'; 

function AxiosList() {

const dispatch = useDispatch();

useEffect(() => {
  dispatch(fetchPosts())
},[]);

const posts = useSelector(state => state.posts);

  return (
    <div className= "posts-container">
      <h2>Users List</h2>
      <div className= "posts-details">
        {posts &&
         posts.posts &&
          posts.posts.map(post => 
            <div className= "each-post">
              <p>ID: {post.id}</p>
              <p>User ID: {post.userId}</p>
              <p>Title: {post.title}</p>
              <p><small>Body: {post.body}</small></p>
            </div>
          )       
        }
      </div>
    </div>
  )
}

export default AxiosList
