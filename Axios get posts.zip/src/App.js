import './App.css';
import AxiosList from './components/axiosList';

function App() {
  return (
    <div className="App">
      <AxiosList />
    </div>
  );
}

export default App;
